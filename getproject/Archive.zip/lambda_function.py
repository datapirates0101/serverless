import json
import pymysql
import os
import utils.util as ut

connection = pymysql.connect(
    host=os.environ['endpoint'], user=os.environ['username'], passwd=os.environ['password'], db=os.environ['database_name'])

def lambda_handler(event, context):
    cur = connection.cursor()
    cur.execute("SELECT * FROM projects")
    rdsprojects = cur.fetchall()
    return ut.buildResponse(200, rdsprojects)


