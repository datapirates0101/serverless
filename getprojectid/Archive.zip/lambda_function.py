import json
import pymysql
import os
import utils.util as ut
connection = pymysql.connect(
    host=os.environ['endpoint'], user=os.environ['username'], passwd=os.environ['password'], db=os.environ['database_name'])

def lambda_handler(event, context):
    data = json.loads(event['body'])
    print(event['body'])
    cur = connection.cursor()
    cur.execute(f'SELECT id FROM projects where project_name = "{event["body"]["project_name"]}"')
    rdsprojectid = cur.fetchone()
    cur.close()
    return ut.buildResponse(200, rdsprojectid)

