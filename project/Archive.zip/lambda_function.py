import json
import pymysql
import os
import utils.util as ut

connection = pymysql.connect(
    host=os.environ['endpoint'], user=os.environ['username'], passwd=os.environ['password'], db=os.environ['database_name'])

def lambda_handler(event, context):
    print(event)
    print(json.dumps(event))
    return{
        "statusCode": 200,
        "body": 'test'
    }

def add_project(event):
    id =  event['body']['id']
    project_name =  event['body']['project_name']
    project_desc = event['body']['project_desc']
    project_creator =  event['body']['project_creator']
    date_time = event['body']['date_time']

    project = {
        "id": id,
        "project_name": project_name,
        "project_desc": project_desc,
        "project_creator": project_creator,
        "date_time": date_time
    }

    project_name = getProjectName(project_name)
    if project_name != None:
        return{
            "statusCode": 401,
            "body": 'Project already exists'
        }
    else:
         saveProjectInfo(project)
    
    return ut.buildResponse(200, {'message': 'Project created successfully'})

def getProjectName(project_name):
    cur = connection.cursor()
    cur.execute(
        f'select project_name from projects where project_name = "{project_name}" ')
    rdsuser = cur.fetchone()
    cur.close()
    return rdsuser


def saveProjectInfo(project):
    print('worked')
    cur = connection.cursor()
    cur.execute(
        f'insert into projects (id, project_name, project_desc, project_creator, date_time) values ("{project["id"]}", "{project["project_name"]}", "{project["project_desc"]}", "{project["project_creator"]}", "{project["date_time"]}")')
    cur.close()
    connection.commit()
