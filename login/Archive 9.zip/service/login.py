import pymysql
import utils.util as ut
import service.register as reg
import os


def login(event):
    username = event['username']
    password = event['password']

    if(username == "" or password == ""):
        return ut.buildResponse(401, {'message': 'missing required fields'})

    rdsuser = reg.getUserName(username)
    if(rdsuser == None):
        return ut.buildResponse(401, {'message': 'username does not exist'})

    rdspassword = getPasswordByUsername(username)

    if(rdspassword[0] != password):
        return ut.buildResponse(401, {'message': 'incorrect password'})

    return ut.buildResponse(200, {'message': 'user logged in successfully'})


def getPasswordByUsername(username):
    connection = pymysql.connect(
        host=os.environ['endpoint'], user=os.environ['username'], passwd=os.environ['password'], db=os.environ['database_name'])
    cur = connection.cursor()
    cur.execute(f'select password from user where username = "{username}" ')
    rdsuserpass = cur.fetchone()
    cur.close()
    return rdsuserpass
