import pymysql
import utils.util as ut

endpoint = 'cloudops-intern.cqsfa5whiluu.us-east-1.rds.amazonaws.com'
username = 'admin'
password = 'Tally1234'
database_name = 'bugtracker'

connection = pymysql.connect(
    host=endpoint, user=username, passwd=password, db=database_name)


def register(event):
    firstname = event['firstname']
    lastname = event['lastname']
    username = event['username']
    email = event['email']
    password = event['password']

    if(firstname == None or lastname == None or username == None or email == None or password == None):
        return ut.buildResponse(401, {'message': 'missing required fields'})

    rdsuser = getUserName(username)
    print(rdsuser)
    if(rdsuser != None):
        return ut.buildResponse(401, {'message': 'username already exists'})

    user = {
        'firstname': firstname,
        'lastname': lastname,
        'username': username.lower(),
        'email': email.lower(),
        'password': password
    }

    saveUserInfo(user)

    return ut.buildResponse(200, {'message': 'user created successfully'})


def getUserName(username):
    cur = connection.cursor()
    cur.execute(f'select username from user where username = "{username}" ')
    rdsuser = cur.fetchone()
    cur.close()
    return rdsuser


def saveUserInfo(user):
    print('worked')
    cur = connection.cursor()
    cur.execute(
        f'insert into user (firstname, lastname, username, email, password) values ("{user["firstname"]}", "{user["lastname"]}", "{user["username"]}", "{user["email"]}", "{user["password"]}")')
    cur.close()
    connection.commit()
