import json
import pymysql
import service.register as reg

healthPath = '/health'
registerPath = '/register'
loginPath = '/login'
verifyPath = '/verify'


def lambda_handler(event, context):
    responseOk = {'statusCode': 200, 'body': 'OK'}
    response = {}
    responseNotFound = {'statusCode': 404, 'body': 'Not Found'}
    if event['path'] == healthPath:
        return responseOk
    elif event['path'] == registerPath:
        response = reg.register(event)
    elif event['path'] == loginPath:
        return responseOk
    elif event['path'] == verifyPath:
        return responseOk
    else:
        return responseNotFound

    return response
